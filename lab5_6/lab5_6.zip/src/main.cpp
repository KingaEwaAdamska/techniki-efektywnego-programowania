#include "CmdInterface.hpp"

int main() {
  CmdInterface cmdTree;

  cmdTree.commandHandler();
}
