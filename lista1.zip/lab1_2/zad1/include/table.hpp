#include <iostream>

const int valueToFill = 34;

bool allocTableFill34(int **table, int size);
bool showAllocatedTable(int *table, int size);
