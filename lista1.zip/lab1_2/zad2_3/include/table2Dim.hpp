
bool allocTable2Dim(int ***table, int sizeX, int sizeY);
bool deallocTable2Dim(int ***table, int sizeX);

